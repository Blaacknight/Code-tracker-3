# Code Authorship Tracker

A VS Code extension that tracks whether code was written by a **Human (H)**, an **AI/Agentic tool (L)**, or is a **Comment (C)** — with real-time editor decorations and Git-synced authorship metadata.

---

## Features

### 🎯 Real-Time Authorship Classification

| Type | Symbol | Description |
|------|--------|-------------|
| Human | `H` | Direct keystrokes, IDE autocomplete, formatting, paste from own workspace |
| AI / Agentic | `L` | Multi-character blocks, file rewrites by tools like Cline, Copilot, or block pastes |
| Comment | `C` | Any character inside single-line or multi-line comment syntax |

### 🎨 Editor Decorations
- **Green left border** — Human-written lines
- **Blue left border + subtle highlight** — AI-written lines
- **Overview ruler** — Scroll-level authorship heatmap

### 📊 Authorship Report
- Per-file and workspace-wide `Human %` vs `AI %`
- Comments **excluded** from ratio (documentation doesn't skew metrics)
- Interactive webview with visual composition bars

### 🔄 Git Synchronization
- Authorship stored in `.authorship/` folder as JSON companion files
- Uses `merge=union` git strategy to minimize merge conflicts
- Detects `git pull` / `git checkout` file changes — doesn't misclassify them as AI
- Automatic conflict marker repair on companion files

### ⏪ Undo/Redo Resilience
- Full authorship history preserved through the undo/redo stack
- Exact authorship state restored on undo — never re-evaluated

### 🖱️ Multi-Cursor Support
- All cursor positions processed correctly in a single edit event

---

## Installation

```bash
cd code-authorship-tracker
npm install
npm run compile
```

Then press **F5** in VS Code to launch the Extension Development Host.

To package: `npx vsce package`

---

## Classification Logic

### Human (H)
- Single keystroke (any char)
- Insertion < 5 characters (configurable `multiCharThreshold`)
- Whitespace/newline-only insertions (auto-indent, bracket closing)
- Paste where the clipboard content matches text copied from the same workspace

### AI / Agentic (L)
- Insertion ≥ 5 characters (default threshold)
- Multi-line block insertions
- Content from external clipboard (copied from outside the workspace)

### Comment (C)
- Any character that falls within detected comment regions for the file's language
- Comment detection supports 25+ languages including Python docstrings, JSDoc, HTML comments, Lua blocks, etc.
- Comment re-overlay runs after every edit to handle new comment blocks being opened/closed

---

## Git Synchronization Protocol

### Companion File Format
Each source file `src/foo.ts` gets a companion:
```
.authorship/src__foo.ts.auth.json
```

```json
{
  "version": 1,
  "filePath": "src/foo.ts",
  "contentHash": "a3f4b2c1d0e5f6a7",
  "runsEncoded": "H45,L120,C30,H200",
  "lastModified": 1703123456789,
  "authorId": "dev@company.com"
}
```

### Run Encoding Format
`H45,L120,C30` = 45 Human chars, then 120 AI chars, then 30 Comment chars.
This compact format minimizes file size and diff noise.

### No-Conflict Strategy
`.authorship/.gitattributes` sets:
```
*.auth.json merge=union
```
This tells Git to keep both sides of any conflict (union merge), which is safe because each developer overwrites the full state of their own edits.

### Line Shift Reconciliation
When a `git pull` shifts lines (Developer A added 10 lines at top), the extension:
1. Detects the external file change via `FileSystemWatcher`
2. Loads the saved companion authorship
3. Uses LCS-based line matching to map old line authorship to new positions
4. Preserves authorship for unchanged lines, defaults new lines to Human

### Conflict Marker Handling
If a `.auth.json` companion file gets Git conflict markers, the extension:
1. Detects the `<<<<<<<` markers on reload
2. Parses both sides as JSON
3. Keeps the side with the most recent `lastModified` timestamp
4. Writes the repaired file atomically

---

## Commands

| Command | Description |
|---------|-------------|
| `Code Authorship: Show Report` | Open workspace-wide webview report |
| `Code Authorship: Show File Report` | Open report focused on current file |
| `Code Authorship: Toggle Decorations` | Show/hide editor color decorations |
| `Code Authorship: Reset File Authorship` | Reset current file to all-Human |
| `Code Authorship: Sync Now` | Force-sync all companion files to disk |

---

## Configuration

```json
{
  "codeAuthorship.showDecorations": true,
  "codeAuthorship.multiCharThreshold": 5,
  "codeAuthorship.excludePatterns": [
    "**/node_modules/**",
    "**/.git/**",
    "**/dist/**",
    "**/out/**"
  ],
  "codeAuthorship.syncOnSave": true
}
```

---

## Architecture

```
src/
├── extension.ts              # Main entry point, event orchestration
├── core/
│   ├── types.ts              # All TypeScript interfaces
│   ├── runEncoding.ts        # RLE compression for authorship data
│   ├── commentDetector.ts    # Per-language comment region parsing
│   ├── classifier.ts         # H/L/C classification logic
│   └── stateManager.ts       # Per-file state + undo/redo history
├── sync/
│   ├── persistence.ts        # Disk read/write, companion files
│   └── gitIntegration.ts     # Git operation detection, line shifting
├── reporting/
│   └── reporter.ts           # Metrics calculation
├── ui/
│   ├── decorations.ts        # Editor decorations + status bar
│   └── reportPanel.ts        # Webview HTML report
└── test/
    └── suite.ts              # Unit tests (no VS Code dependency)
```

---

## Running Tests

```bash
npm run compile
npx ts-node src/test/suite.ts
```

---

## Line Ending Handling

All internal state uses `\n` (LF) normalized from CRLF. This ensures:
- Character offsets are consistent across Windows/Mac/Linux
- Run lengths don't change when files are committed with different line endings
- Git's `core.autocrlf` setting doesn't affect tracking accuracy

---

## Supported Languages for Comment Detection

TypeScript, JavaScript, JSX/TSX, Python, Ruby, Java, C, C++, C#, Go, Rust, Swift, Kotlin, Scala, PHP, HTML, XML, CSS, SCSS, Less, YAML, TOML, INI, Lua, SQL, Haskell, Elm, Clojure, Bash, PowerShell, Perl, R, Vue

---

## License

MIT
