import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import * as crypto from 'crypto';
import { FileAuthorshipState, AuthorshipDiskRecord, AuthorRun } from '../core/types';
import { encodeRuns, decodeRuns, mergeRuns } from '../core/runEncoding';
import { normalizeText, hashContent } from '../core/stateManager';

const AUTHORSHIP_DIR = '.authorship';
const RECORD_VERSION = 1;

/**
 * Gets a stable developer identifier (git user.email preferred, falls back to hostname).
 */
async function getDeveloperId(): Promise<string> {
  try {
    const terminal = await runShell('git config user.email');
    if (terminal) { return terminal.trim(); }
  } catch { /* ignore */ }
  return os.hostname();
}

/**
 * Runs a shell command and returns stdout.
 */
function runShell(cmd: string): Promise<string> {
  const { execSync } = require('child_process');
  try {
    return Promise.resolve(execSync(cmd, { encoding: 'utf8' }));
  } catch {
    return Promise.resolve('');
  }
}

/**
 * Gets the workspace root path.
 */
export function getWorkspaceRoot(): string | undefined {
  return vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
}

/**
 * Returns the path to the .authorship directory for this workspace.
 */
export function getAuthorshipDir(workspaceRoot: string): string {
  return path.join(workspaceRoot, AUTHORSHIP_DIR);
}

/**
 * Converts an absolute file path to a relative path suitable for authorship filenames.
 */
export function filePathToRelative(filePath: string, workspaceRoot: string): string {
  return path.relative(workspaceRoot, filePath).replace(/\\/g, '/');
}

/**
 * Returns the path to a companion .auth.json file for a source file.
 */
export function getCompanionPath(filePath: string, workspaceRoot: string): string {
  const rel = filePathToRelative(filePath, workspaceRoot);
  // Flatten path separators to avoid deep nesting
  const safe = rel.replace(/\//g, '__');
  return path.join(getAuthorshipDir(workspaceRoot), `${safe}.auth.json`);
}

/**
 * Ensures the .authorship directory exists and is git-tracked with a .gitattributes
 * entry that uses union merge strategy to minimize conflicts.
 */
export async function ensureAuthorshipDir(workspaceRoot: string): Promise<void> {
  const dir = getAuthorshipDir(workspaceRoot);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  // Write .gitattributes if not present
  const gitattrsPath = path.join(dir, '.gitattributes');
  if (!fs.existsSync(gitattrsPath)) {
    fs.writeFileSync(gitattrsPath, '*.auth.json merge=union\n', 'utf8');
  }

  // Write .gitignore exclusion to NOT ignore authorship files
  const rootGitignore = path.join(workspaceRoot, '.gitignore');
  if (fs.existsSync(rootGitignore)) {
    const existing = fs.readFileSync(rootGitignore, 'utf8');
    if (!existing.includes('.authorship')) {
      // Don't add — authorship should be tracked
    }
  }
}

/**
 * Saves a FileAuthorshipState to its companion file.
 */
export async function saveAuthorshipState(
  state: FileAuthorshipState,
  workspaceRoot: string
): Promise<void> {
  await ensureAuthorshipDir(workspaceRoot);
  const companionPath = getCompanionPath(state.filePath, workspaceRoot);
  const authorId = await getDeveloperId();

  const record: AuthorshipDiskRecord = {
    version: RECORD_VERSION,
    filePath: filePathToRelative(state.filePath, workspaceRoot),
    contentHash: state.contentHash,
    runsEncoded: encodeRuns(state.runs),
    lastModified: state.lastModified,
    authorId,
  };

  // Atomic write: write to temp then rename
  const tmpPath = companionPath + '.tmp';
  fs.writeFileSync(tmpPath, JSON.stringify(record, null, 2), 'utf8');
  fs.renameSync(tmpPath, companionPath);
}

/**
 * Loads a FileAuthorshipState from its companion file.
 * Returns null if the companion file doesn't exist.
 */
export function loadAuthorshipState(
  filePath: string,
  workspaceRoot: string
): { runs: AuthorRun[]; hash: string } | null {
  const companionPath = getCompanionPath(filePath, workspaceRoot);
  if (!fs.existsSync(companionPath)) { return null; }

  try {
    const raw = fs.readFileSync(companionPath, 'utf8');
    const record = JSON.parse(raw) as AuthorshipDiskRecord;

    if (record.version !== RECORD_VERSION) {
      console.warn(`[AuthorshipTracker] Unknown record version: ${record.version}`);
      return null;
    }

    const runs = decodeRuns(record.runsEncoded);
    return { runs: mergeRuns(runs), hash: record.contentHash };
  } catch (err) {
    console.error(`[AuthorshipTracker] Failed to load companion: ${err}`);
    return null;
  }
}

/**
 * Handles a git merge conflict in a companion file by preferring the
 * union of both sides (keeping more data is safer than losing it).
 * Returns the repaired JSON, or null if repair failed.
 */
export function repairConflictedCompanion(raw: string): string | null {
  // Remove conflict markers and try to merge both sides
  const conflictRe = /<<<<<<< .+?\n([\s\S]*?)=======\n([\s\S]*?)>>>>>>> .+?\n/g;
  let repaired = raw;
  const matches = [...raw.matchAll(conflictRe)];

  if (matches.length === 0) { return null; }

  for (const match of matches) {
    const ours = match[1];
    const theirs = match[2];

    // Try to parse both as JSON records and merge
    try {
      const ourRecord = JSON.parse(ours) as AuthorshipDiskRecord;
      const theirRecord = JSON.parse(theirs) as AuthorshipDiskRecord;

      // Keep the most recent modification
      const winner = ourRecord.lastModified >= theirRecord.lastModified
        ? ourRecord
        : theirRecord;

      repaired = repaired.replace(match[0], JSON.stringify(winner, null, 2) + '\n');
    } catch {
      // Can't parse — remove the conflict markers and keep ours
      repaired = repaired.replace(match[0], ours);
    }
  }

  return repaired;
}

/**
 * Watches the .authorship directory for changes from other developers
 * (e.g., after a git pull updates companion files).
 */
export class CompanionFileWatcher {
  private watcher: vscode.FileSystemWatcher | null = null;
  private _onCompanionChanged = new vscode.EventEmitter<string>();
  public readonly onCompanionChanged = this._onCompanionChanged.event;

  public start(workspaceRoot: string): void {
    const pattern = new vscode.RelativePattern(
      workspaceRoot,
      `${AUTHORSHIP_DIR}/**/*.auth.json`
    );
    this.watcher = vscode.workspace.createFileSystemWatcher(pattern);

    this.watcher.onDidChange(uri => {
      this._onCompanionChanged.fire(uri.fsPath);
    });
    this.watcher.onDidCreate(uri => {
      this._onCompanionChanged.fire(uri.fsPath);
    });
  }

  public dispose(): void {
    this.watcher?.dispose();
    this._onCompanionChanged.dispose();
  }
}

/**
 * Watches the workspace source files for external git changes.
 */
export class SourceFileWatcher {
  private watcher: vscode.FileSystemWatcher | null = null;
  private _onExternalChange = new vscode.EventEmitter<vscode.Uri>();
  public readonly onExternalChange = this._onExternalChange.event;

  /** Files currently being saved by VS Code itself — don't re-process */
  private savingFiles: Set<string> = new Set();

  public markSaving(filePath: string): void {
    this.savingFiles.add(filePath);
    setTimeout(() => this.savingFiles.delete(filePath), 2000);
  }

  public start(workspaceRoot: string): void {
    const pattern = new vscode.RelativePattern(workspaceRoot, '**/*');
    this.watcher = vscode.workspace.createFileSystemWatcher(pattern);

    this.watcher.onDidChange(uri => {
      if (!this.savingFiles.has(uri.fsPath)) {
        this._onExternalChange.fire(uri);
      }
    });
  }

  public dispose(): void {
    this.watcher?.dispose();
    this._onExternalChange.dispose();
  }
}
