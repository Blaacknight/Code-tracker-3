import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import { AuthorRun, AuthorType } from '../core/types';
import { expandRuns, mergeRuns } from '../core/runEncoding';

/**
 * Detects if a git operation is currently in progress in the workspace.
 * Checks for common git lock files and MERGE_HEAD, CHERRY_PICK_HEAD, etc.
 */
export function isGitOperationInProgress(workspaceRoot: string): boolean {
  const indicators = [
    '.git/MERGE_HEAD',
    '.git/CHERRY_PICK_HEAD',
    '.git/REBASE_HEAD',
    '.git/BISECT_LOG',
    '.git/index.lock',
  ];

  for (const indicator of indicators) {
    if (fs.existsSync(path.join(workspaceRoot, indicator))) {
      return true;
    }
  }
  return false;
}

/**
 * Detects if the current file change looks like a full-file git replacement
 * (e.g., git checkout or git pull rewrote the file entirely).
 *
 * Heuristic: a single change that replaces the entire document content
 * and the change came from an external source.
 */
export function isFullFileReplacement(
  changes: readonly vscode.TextDocumentContentChangeEvent[]
): boolean {
  if (changes.length !== 1) { return false; }
  const change = changes[0];
  // A full replacement would have a large range starting at 0
  return change.rangeOffset === 0 && change.rangeLength > 50;
}

/**
 * Applies line-based offset shifting to an authorship run array.
 * Used when merging upstream changes that shift lines.
 *
 * @param runs        Existing authorship runs
 * @param text        Full document text BEFORE the shift
 * @param newText     Full document text AFTER the shift
 * @returns Adjusted runs where unchanged lines keep their authorship
 */
export function applyLineShift(
  runs: AuthorRun[],
  text: string,
  newText: string
): AuthorRun[] {
  const oldLines = text.split('\n');
  const newLines = newText.split('\n');
  const chars = expandRuns(runs);

  // Build offset map for old lines
  const oldLineOffsets: number[] = [];
  let offset = 0;
  for (const line of oldLines) {
    oldLineOffsets.push(offset);
    offset += line.length + 1;
  }

  // LCS-based line matching to find which old lines correspond to new lines
  // For performance, we use a simple hash-based approach
  const oldLineMap = new Map<string, number>();
  for (let i = 0; i < oldLines.length; i++) {
    if (!oldLineMap.has(oldLines[i])) {
      oldLineMap.set(oldLines[i], i);
    }
  }

  // Build new per-character authorship
  const newChars: AuthorType[] = [];
  let newOffset = 0;

  for (let newLineIdx = 0; newLineIdx < newLines.length; newLineIdx++) {
    const newLine = newLines[newLineIdx];
    const oldLineIdx = oldLineMap.get(newLine);

    if (oldLineIdx !== undefined) {
      // Line exists in old file — copy authorship
      const oldOffset = oldLineOffsets[oldLineIdx];
      for (let col = 0; col < newLine.length; col++) {
        newChars.push(chars[oldOffset + col] ?? 'H');
      }
    } else {
      // New line (inserted by git) — mark as Human (git content)
      for (let col = 0; col < newLine.length; col++) {
        newChars.push('H');
      }
    }

    // Add newline character
    if (newLineIdx < newLines.length - 1) {
      newChars.push('H'); // newline chars
    }
  }

  return mergeRuns(newChars.map(a => ({ author: a, length: 1 })));
}

/**
 * Strips git conflict markers from a file and returns the cleaned content.
 * Keeps "ours" side of the conflict.
 */
export function stripConflictMarkers(text: string): string {
  const conflictRe = /<<<<<<< .+?\n([\s\S]*?)=======\n[\s\S]*?>>>>>>> .+?\n/g;
  return text.replace(conflictRe, '$1');
}

/**
 * Detects conflict markers in text.
 */
export function hasConflictMarkers(text: string): boolean {
  return /^<{7} /m.test(text) || /^={7}$/m.test(text) || /^>{7} /m.test(text);
}

/**
 * Returns the git user email for the current workspace.
 */
export async function getGitUserEmail(workspaceRoot: string): Promise<string | null> {
  try {
    const { execSync } = require('child_process');
    const email = execSync('git config user.email', {
      cwd: workspaceRoot,
      encoding: 'utf8',
    }).trim();
    return email || null;
  } catch {
    return null;
  }
}

/**
 * Returns the current git branch name.
 */
export async function getCurrentBranch(workspaceRoot: string): Promise<string | null> {
  try {
    const { execSync } = require('child_process');
    const branch = execSync('git rev-parse --abbrev-ref HEAD', {
      cwd: workspaceRoot,
      encoding: 'utf8',
    }).trim();
    return branch || null;
  } catch {
    return null;
  }
}

/**
 * Returns the list of files modified in the last git pull.
 */
export async function getLastPullChangedFiles(workspaceRoot: string): Promise<string[]> {
  try {
    const { execSync } = require('child_process');
    const output = execSync('git diff --name-only HEAD@{1} HEAD', {
      cwd: workspaceRoot,
      encoding: 'utf8',
    }).trim();
    if (!output) { return []; }
    return output.split('\n').map((f: string) => path.join(workspaceRoot, f));
  } catch {
    return [];
  }
}
