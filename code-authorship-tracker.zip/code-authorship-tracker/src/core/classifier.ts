import * as vscode from 'vscode';
import { AuthorType, AuthorRun, ClipboardEntry } from './types';
import { buildCommentMap, isRangePartiallyComment } from './commentDetector';
import { mergeRuns } from './runEncoding';

/**
 * Heuristics used to classify a text insertion as H or L.
 */
interface ClassifyOptions {
  /** The inserted text */
  text: string;
  /** Length of text deleted at same position (context for paste detection) */
  deletedLength: number;
  /** Language of the document */
  languageId: string;
  /** Whether VS Code reports this as coming from a known AI command */
  isKnownAiSource: boolean;
  /** The current clipboard state tracked by us */
  clipboard: ClipboardEntry | null;
  /** The full normalized document text BEFORE the edit */
  documentText: string;
  /** Offset in document where insert begins */
  offset: number;
}

/**
 * Returns the configured multi-char threshold.
 */
function getMultiCharThreshold(): number {
  return vscode.workspace
    .getConfiguration('codeAuthorship')
    .get<number>('multiCharThreshold', 5);
}

/**
 * Determines whether a single insertion is Human or AI.
 * Does NOT handle comment reclassification — that's done by the state manager
 * which overlays comment regions on top.
 */
export function classifyInsertion(opts: ClassifyOptions): AuthorType {
  const { text, languageId, isKnownAiSource, clipboard, documentText, offset } = opts;

  // Empty insert (delete-only) — no new authorship needed
  if (text.length === 0) { return 'H'; }

  // ── Explicit AI source ─────────────────────────────────────────────────────
  if (isKnownAiSource) { return 'L'; }

  const threshold = getMultiCharThreshold();

  // ── Single-character typing ────────────────────────────────────────────────
  // Single chars are always Human (direct keyboard input).
  if (text.length === 1) { return 'H'; }

  // ── Clipboard paste handling ───────────────────────────────────────────────
  // If the pasted text matches what we recorded as copied from THIS workspace,
  // it's still Human-authored code being moved around.
  if (clipboard && text === clipboard.text) {
    return 'H';
  }

  // ── Multi-char threshold ───────────────────────────────────────────────────
  // Small insertions under the threshold are likely IDE autocomplete or
  // bracket closing — treat as Human.
  if (text.length < threshold) { return 'H'; }

  // ── Newline-only insertions ────────────────────────────────────────────────
  // Enter key with auto-indent = Human.
  const trimmed = text.replace(/\r\n/g, '\n');
  if (/^\n\s*$/.test(trimmed)) { return 'H'; }

  // ── Formatting / whitespace-only insertions ────────────────────────────────
  if (/^\s+$/.test(trimmed)) { return 'H'; }

  // ── Multi-line or long single-line block → AI ──────────────────────────────
  if (trimmed.includes('\n')) { return 'L'; }
  if (text.length >= threshold) { return 'L'; }

  return 'H';
}

/**
 * Builds an AuthorRun[] for an inserted text string, taking into account:
 * 1. The base H/L classification from classifyInsertion()
 * 2. Comment regions within the inserted text
 *
 * Characters that fall inside comment syntax are always marked 'C',
 * regardless of whether a human or AI typed them.
 */
export function buildInsertedRuns(
  text: string,
  baseAuthor: AuthorType,
  languageId: string,
  documentText: string,
  insertOffset: number
): AuthorRun[] {
  if (text.length === 0) { return []; }

  // Build a comment map for the *inserted text* in isolation.
  // We also need to check the surrounding context for open block comments.
  // For simplicity, build a comment map of the full document after insert.
  const fullText = documentText.slice(0, insertOffset) + text + documentText.slice(insertOffset);
  const commentMap = buildCommentMap(fullText, languageId);

  const runs: AuthorRun[] = [];
  for (let i = 0; i < text.length; i++) {
    const docIdx = insertOffset + i;
    const author: AuthorType = commentMap[docIdx] ? 'C' : baseAuthor;
    const last = runs[runs.length - 1];
    if (last && last.author === author) {
      last.length++;
    } else {
      runs.push({ author, length: 1 });
    }
  }

  return mergeRuns(runs);
}

/**
 * Re-evaluates comment regions across the ENTIRE document and returns
 * a new run array that correctly marks all comment characters as 'C',
 * while preserving H/L for non-comment characters.
 *
 * This is called after every edit to ensure comment boundaries are correct.
 */
export function overlayComments(
  existingRuns: AuthorRun[],
  documentText: string,
  languageId: string
): AuthorRun[] {
  if (documentText.length === 0) { return []; }

  const commentMap = buildCommentMap(documentText, languageId);

  // Expand existing runs to per-character array
  const perChar: AuthorType[] = [];
  for (const run of existingRuns) {
    for (let i = 0; i < run.length; i++) {
      perChar.push(run.author);
    }
  }

  // Pad or trim to match document length
  while (perChar.length < documentText.length) { perChar.push('H'); }
  const trimmed = perChar.slice(0, documentText.length);

  // Apply comment overlay: any char that is now in a comment → 'C'
  // But if char was already 'C' and is no longer in a comment, revert to 'H'
  // (we can't recover the original H/L for comment chars — use 'H' as safe default)
  const result: AuthorRun[] = [];
  for (let i = 0; i < trimmed.length; i++) {
    let author: AuthorType;
    if (commentMap[i]) {
      author = 'C';
    } else if (trimmed[i] === 'C') {
      // Was a comment char, no longer in comment region → treat as Human
      author = 'H';
    } else {
      author = trimmed[i];
    }
    const last = result[result.length - 1];
    if (last && last.author === author) {
      last.length++;
    } else {
      result.push({ author, length: 1 });
    }
  }

  return result;
}

/**
 * Detects if the given text change looks like a git conflict marker
 * being inserted or resolved.
 */
export function isGitConflictMarker(text: string): boolean {
  return /^(<{7}|={7}|>{7})/.test(text.trimStart());
}

/**
 * Detects if a file change is coming from a git operation
 * (pull, checkout, merge) by checking VS Code's change reason.
 */
export function isExternalGitChange(
  reason: vscode.TextDocumentChangeReason | undefined
): boolean {
  // VS Code exposes reason === 1 for undo, 2 for redo.
  // External file changes (git operations) come through as saves with no reason
  // or through onDidChangeTextDocument with undefined reason and large replace-all changes.
  // We detect them separately via the FileSystemWatcher.
  return reason === undefined;
}
