import * as vscode from 'vscode';
import * as crypto from 'crypto';
import {
  FileAuthorshipState,
  AuthorRun,
  UndoRedoStack,
  AuthorshipSnapshot,
  ClipboardEntry,
  AuthorType,
} from './types';
import {
  applyEdit,
  mergeRuns,
  cloneRuns,
  totalLength,
  encodeRuns,
} from './runEncoding';
import {
  classifyInsertion,
  buildInsertedRuns,
  overlayComments,
  isGitConflictMarker,
} from './classifier';

const MAX_UNDO_STACK = 200;

/**
 * Normalizes line endings to \n for consistent offset tracking.
 */
export function normalizeText(text: string): string {
  return text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
}

/**
 * Computes a short SHA-256 hash of a text string.
 */
export function hashContent(text: string): string {
  return crypto.createHash('sha256').update(text, 'utf8').digest('hex').slice(0, 16);
}

/**
 * Manages the authorship state for all open documents.
 */
export class AuthorshipStateManager {
  /** filePath → current authorship state */
  private states: Map<string, FileAuthorshipState> = new Map();
  /** filePath → undo/redo stacks */
  private history: Map<string, UndoRedoStack> = new Map();
  /** Last known clipboard content */
  private clipboard: ClipboardEntry | null = null;
  /** Files currently being reloaded from disk (git operations) — skip change events */
  private externalReloadSet: Set<string> = new Set();
  /** Emits when any file's state changes */
  private _onStateChanged = new vscode.EventEmitter<string>();
  public readonly onStateChanged = this._onStateChanged.event;

  /**
   * Returns the current authorship state for a file, or undefined.
   */
  public getState(filePath: string): FileAuthorshipState | undefined {
    return this.states.get(filePath);
  }

  /**
   * Initializes authorship state for a document.
   * Called when a document is opened or reloaded.
   */
  public initializeFile(
    filePath: string,
    content: string,
    existingRuns?: AuthorRun[],
    existingHash?: string
  ): FileAuthorshipState {
    const normalized = normalizeText(content);
    const hash = hashContent(normalized);

    let runs: AuthorRun[];

    if (existingRuns && existingHash) {
      if (existingHash === hash) {
        // File unchanged since last sync — use saved authorship
        runs = cloneRuns(existingRuns);
      } else {
        // File changed externally — try to reconcile
        runs = this.reconcileRuns(existingRuns, normalized);
      }
    } else {
      // New file — default all to Human
      runs = normalized.length > 0
        ? [{ author: 'H', length: normalized.length }]
        : [];
    }

    const state: FileAuthorshipState = {
      filePath,
      contentHash: hash,
      runs: mergeRuns(runs),
      version: 1,
      lastModified: Date.now(),
    };

    this.states.set(filePath, state);
    this.history.set(filePath, { past: [], future: [] });
    return state;
  }

  /**
   * Handles a VS Code TextDocumentChangeEvent.
   * This is the core event processor.
   */
  public handleDocumentChange(
    event: vscode.TextDocumentChangeEvent,
    isUndoRedo: boolean
  ): void {
    const filePath = event.document.uri.fsPath;

    if (this.externalReloadSet.has(filePath)) {
      return; // Skip changes triggered by git operations
    }

    let state = this.states.get(filePath);
    if (!state) {
      // Auto-initialize if not yet tracked
      state = this.initializeFile(filePath, event.document.getText());
    }

    // ── Undo/Redo handling ─────────────────────────────────────────────────
    const stack = this.history.get(filePath)!;

    if (isUndoRedo) {
      // VS Code has already applied the undo/redo to the document.
      // We need to restore the corresponding snapshot rather than re-classify.
      this.handleUndoRedo(filePath, event, stack, isUndoRedo, state);
      return;
    }

    // ── Normal edit ────────────────────────────────────────────────────────
    // Save current state to undo stack before modifying
    this.pushUndo(stack, state);

    const normalized = normalizeText(event.document.getText());
    const languageId = event.document.languageId;

    // Process all changes (multi-cursor support)
    // VS Code delivers them in reverse document order — we must apply in order.
    const changes = [...event.contentChanges].sort((a, b) => a.rangeOffset - b.rangeOffset);

    let cumulativeOffset = 0; // tracks offset drift as we apply changes

    for (const change of changes) {
      const offset = change.rangeOffset + cumulativeOffset;
      const deletedLength = change.rangeLength;
      const insertedText = normalizeText(change.text);

      if (deletedLength === 0 && insertedText.length === 0) { continue; }

      // Detect git conflict markers — treat as Human interaction
      const isConflictMarker = isGitConflictMarker(insertedText);

      // Classify the insertion
      const baseAuthor = isConflictMarker ? 'H' : classifyInsertion({
        text: insertedText,
        deletedLength,
        languageId,
        isKnownAiSource: false,
        clipboard: this.clipboard,
        documentText: normalized,
        offset,
      });

      // Build per-character runs for the inserted text
      const insertedRuns = buildInsertedRuns(
        insertedText,
        baseAuthor,
        languageId,
        normalized,
        offset
      );

      // Apply edit to the run array
      state.runs = applyEdit(state.runs, offset, deletedLength, insertedRuns);

      // Adjust cumulative offset
      cumulativeOffset += insertedText.length - deletedLength;
    }

    // Re-overlay comment regions across the full document
    state.runs = overlayComments(state.runs, normalized, languageId);

    // Validate length consistency
    const expectedLen = normalized.length;
    const actualLen = totalLength(state.runs);
    if (actualLen !== expectedLen) {
      console.warn(
        `[AuthorshipTracker] Run length mismatch: expected ${expectedLen}, got ${actualLen} — resetting`
      );
      state.runs = expectedLen > 0 ? [{ author: 'H', length: expectedLen }] : [];
    }

    state.contentHash = hashContent(normalized);
    state.lastModified = Date.now();
    this.states.set(filePath, state);
    this._onStateChanged.fire(filePath);
  }

  /**
   * Handles an undo or redo event by snapping to the correct history state.
   */
  private handleUndoRedo(
    filePath: string,
    event: vscode.TextDocumentChangeEvent,
    stack: UndoRedoStack,
    _isUndoRedo: boolean,
    state: FileAuthorshipState
  ): void {
    const normalized = normalizeText(event.document.getText());
    const targetHash = hashContent(normalized);

    // Search the undo stack for a snapshot matching the current document state
    let snapshotFound = false;

    // Search past (for undo) and future (for redo)
    for (const snapArr of [stack.past, stack.future]) {
      for (let i = snapArr.length - 1; i >= 0; i--) {
        if (snapArr[i].contentHash === targetHash) {
          state.runs = cloneRuns(snapArr[i].runs);
          state.contentHash = targetHash;
          state.lastModified = Date.now();
          snapshotFound = true;
          break;
        }
      }
      if (snapshotFound) { break; }
    }

    if (!snapshotFound) {
      // No exact match — re-classify conservatively
      const expectedLen = normalized.length;
      const actualLen = totalLength(state.runs);
      if (actualLen !== expectedLen) {
        state.runs = expectedLen > 0 ? [{ author: 'H', length: expectedLen }] : [];
      }
    }

    this.states.set(filePath, state);
    this._onStateChanged.fire(filePath);
  }

  /**
   * Records a copy event so paste can be classified as Human.
   */
  public recordCopy(text: string, sourceUri?: string): void {
    this.clipboard = {
      text,
      sourceUri,
    };
  }

  /**
   * Called when a document is saved — updates the hash.
   */
  public handleDocumentSave(document: vscode.TextDocument): void {
    const filePath = document.uri.fsPath;
    const state = this.states.get(filePath);
    if (!state) { return; }
    const normalized = normalizeText(document.getText());
    state.contentHash = hashContent(normalized);
    state.lastModified = Date.now();
  }

  /**
   * Marks a file as being reloaded from a git operation.
   * Changes during this period are not classified as AI.
   */
  public beginExternalReload(filePath: string): void {
    this.externalReloadSet.add(filePath);
  }

  /**
   * Ends the external reload lock for a file.
   */
  public endExternalReload(filePath: string): void {
    this.externalReloadSet.delete(filePath);
  }

  /**
   * Called when a document is externally changed (git pull/checkout).
   * Reloads the file's authorship from disk metadata.
   */
  public handleExternalFileChange(
    filePath: string,
    newContent: string,
    savedRuns?: AuthorRun[],
    savedHash?: string
  ): void {
    this.initializeFile(filePath, newContent, savedRuns, savedHash);
    this._onStateChanged.fire(filePath);
  }

  /**
   * Removes state for a closed document.
   */
  public removeFile(filePath: string): void {
    this.states.delete(filePath);
    this.history.delete(filePath);
  }

  /**
   * Returns all tracked file paths.
   */
  public getTrackedFiles(): string[] {
    return [...this.states.keys()];
  }

  // ── Private helpers ──────────────────────────────────────────────────────

  private pushUndo(stack: UndoRedoStack, state: FileAuthorshipState): void {
    stack.past.push({
      runs: cloneRuns(state.runs),
      contentHash: state.contentHash,
      timestamp: Date.now(),
    });
    if (stack.past.length > MAX_UNDO_STACK) {
      stack.past.shift();
    }
    // Any new edit clears the redo future
    stack.future = [];
  }

  /**
   * Attempts to reconcile saved runs with a file whose content has changed
   * externally (e.g., git pull changed some lines).
   * Uses a simple line-diff approach: unchanged lines keep their authorship,
   * new lines default to Human.
   */
  private reconcileRuns(savedRuns: AuthorRun[], newContent: string): AuthorRun[] {
    // Build per-character author array from saved runs
    const chars: AuthorType[] = [];
    for (const run of savedRuns) {
      for (let i = 0; i < run.length; i++) {
        chars.push(run.author);
      }
    }

    // For changed content, we default all new chars to 'H'
    // A more sophisticated diff could preserve more authorship,
    // but this is safe for the external-change case.
    if (newContent.length <= chars.length) {
      // Content shrunk — truncate
      const result: AuthorRun[] = [];
      for (let i = 0; i < newContent.length; i++) {
        const author = chars[i] ?? 'H';
        const last = result[result.length - 1];
        if (last && last.author === author) { last.length++; }
        else { result.push({ author, length: 1 }); }
      }
      return mergeRuns(result);
    } else {
      // Content grew — preserve old, append H for new chars
      const result: AuthorRun[] = [];
      for (let i = 0; i < newContent.length; i++) {
        const author: AuthorType = i < chars.length ? chars[i] : 'H';
        const last = result[result.length - 1];
        if (last && last.author === author) { last.length++; }
        else { result.push({ author, length: 1 }); }
      }
      return mergeRuns(result);
    }
  }
}
