import { CommentRegion } from './types';

/**
 * Language comment syntax definitions.
 */
interface CommentSyntax {
  lineComments: string[];
  blockComments: Array<{ start: string; end: string }>;
}

const LANGUAGE_COMMENTS: Record<string, CommentSyntax> = {
  // C-family
  c:          { lineComments: ['//'], blockComments: [{ start: '/*', end: '*/' }] },
  cpp:        { lineComments: ['//'], blockComments: [{ start: '/*', end: '*/' }] },
  java:       { lineComments: ['//'], blockComments: [{ start: '/*', end: '*/' }, { start: '/**', end: '*/' }] },
  javascript: { lineComments: ['//'], blockComments: [{ start: '/*', end: '*/' }] },
  typescript: { lineComments: ['//'], blockComments: [{ start: '/*', end: '*/' }] },
  javascriptreact: { lineComments: ['//'], blockComments: [{ start: '/*', end: '*/' }, { start: '{/*', end: '*/}' }] },
  typescriptreact: { lineComments: ['//'], blockComments: [{ start: '/*', end: '*/' }, { start: '{/*', end: '*/}' }] },
  csharp:     { lineComments: ['//'], blockComments: [{ start: '/*', end: '*/' }] },
  go:         { lineComments: ['//'], blockComments: [{ start: '/*', end: '*/' }] },
  rust:       { lineComments: ['//'], blockComments: [{ start: '/*', end: '*/' }] },
  swift:      { lineComments: ['//'], blockComments: [{ start: '/*', end: '*/' }] },
  kotlin:     { lineComments: ['//'], blockComments: [{ start: '/*', end: '*/' }] },
  scala:      { lineComments: ['//'], blockComments: [{ start: '/*', end: '*/' }] },
  // Script languages
  python:     { lineComments: ['#'], blockComments: [{ start: '"""', end: '"""' }, { start: "'''", end: "'''" }] },
  ruby:       { lineComments: ['#'], blockComments: [{ start: '=begin', end: '=end' }] },
  shellscript: { lineComments: ['#'], blockComments: [] },
  bash:       { lineComments: ['#'], blockComments: [] },
  powershell: { lineComments: ['#'], blockComments: [{ start: '<#', end: '#>' }] },
  perl:       { lineComments: ['#'], blockComments: [] },
  r:          { lineComments: ['#'], blockComments: [] },
  // Web
  html:       { lineComments: [], blockComments: [{ start: '<!--', end: '-->' }] },
  xml:        { lineComments: [], blockComments: [{ start: '<!--', end: '-->' }] },
  css:        { lineComments: [], blockComments: [{ start: '/*', end: '*/' }] },
  scss:       { lineComments: ['//'], blockComments: [{ start: '/*', end: '*/' }] },
  less:       { lineComments: ['//'], blockComments: [{ start: '/*', end: '*/' }] },
  // Data/config
  yaml:       { lineComments: ['#'], blockComments: [] },
  toml:       { lineComments: ['#'], blockComments: [] },
  ini:        { lineComments: [';', '#'], blockComments: [] },
  lua:        { lineComments: ['--'], blockComments: [{ start: '--[[', end: ']]' }] },
  sql:        { lineComments: ['--'], blockComments: [{ start: '/*', end: '*/' }] },
  // Functional
  haskell:    { lineComments: ['--'], blockComments: [{ start: '{-', end: '-}' }] },
  elm:        { lineComments: ['--'], blockComments: [{ start: '{-', end: '-}' }] },
  clojure:    { lineComments: [';'], blockComments: [] },
  // Other
  php:        { lineComments: ['//', '#'], blockComments: [{ start: '/*', end: '*/' }] },
  vue:        { lineComments: ['//'], blockComments: [{ start: '/*', end: '*/' }, { start: '<!--', end: '-->' }] },
};

/**
 * Fallback for unknown languages — tries common patterns.
 */
const FALLBACK_SYNTAX: CommentSyntax = {
  lineComments: ['//'],
  blockComments: [{ start: '/*', end: '*/' }],
};

/**
 * Returns the CommentSyntax for a VS Code language identifier.
 */
export function getCommentSyntax(languageId: string): CommentSyntax {
  return LANGUAGE_COMMENTS[languageId.toLowerCase()] ?? FALLBACK_SYNTAX;
}

/**
 * Parses a normalized (CRLF→LF) document text and returns all comment regions
 * as [startOffset, endOffset] pairs (inclusive of comment delimiters).
 * 
 * String literals are respected — comment markers inside strings are ignored.
 */
export function findCommentRegions(text: string, languageId: string): CommentRegion[] {
  const syntax = getCommentSyntax(languageId);
  const regions: CommentRegion[] = [];
  let i = 0;
  const len = text.length;

  // Simple state machine to track string literal context
  let inString: string | null = null; // the opening delimiter

  while (i < len) {
    // ── String literal tracking ────────────────────────────────────────────
    if (!inString) {
      // Check for string start (single, double, backtick)
      if (text[i] === '"' || text[i] === "'" || text[i] === '`') {
        inString = text[i];
        i++;
        continue;
      }
    } else {
      // Check for string end (handle escape sequences)
      if (text[i] === '\\' && i + 1 < len) {
        i += 2; // skip escaped char
        continue;
      }
      if (text[i] === inString) {
        inString = null;
      }
      i++;
      continue;
    }

    // ── Block comments ─────────────────────────────────────────────────────
    let matchedBlock = false;
    for (const block of syntax.blockComments) {
      if (text.startsWith(block.start, i)) {
        const endIdx = text.indexOf(block.end, i + block.start.length);
        const regionEnd = endIdx === -1 ? len - 1 : endIdx + block.end.length - 1;
        regions.push([i, regionEnd]);
        i = regionEnd + 1;
        matchedBlock = true;
        break;
      }
    }
    if (matchedBlock) { continue; }

    // ── Line comments ──────────────────────────────────────────────────────
    let matchedLine = false;
    for (const lineMarker of syntax.lineComments) {
      if (text.startsWith(lineMarker, i)) {
        // Scan to end of line
        let end = i;
        while (end < len && text[end] !== '\n') { end++; }
        regions.push([i, end - 1]);
        i = end; // position at \n, main loop will advance past it
        matchedLine = true;
        break;
      }
    }
    if (matchedLine) { continue; }

    i++;
  }

  return regions;
}

/**
 * Returns a boolean[] mapping each character index to whether it is inside a comment.
 * This is the primary interface used by the classifier.
 */
export function buildCommentMap(text: string, languageId: string): boolean[] {
  const map: boolean[] = new Array(text.length).fill(false);
  const regions = findCommentRegions(text, languageId);
  for (const [start, end] of regions) {
    for (let i = start; i <= end && i < map.length; i++) {
      map[i] = true;
    }
  }
  return map;
}

/**
 * Checks whether a given offset range is entirely within comment regions.
 */
export function isRangeComment(
  commentMap: boolean[],
  offset: number,
  length: number
): boolean {
  for (let i = offset; i < offset + length && i < commentMap.length; i++) {
    if (!commentMap[i]) { return false; }
  }
  return length > 0;
}

/**
 * Given a comment map, returns whether any character in the range is a comment.
 */
export function isRangePartiallyComment(
  commentMap: boolean[],
  offset: number,
  length: number
): boolean {
  for (let i = offset; i < offset + length && i < commentMap.length; i++) {
    if (commentMap[i]) { return true; }
  }
  return false;
}
