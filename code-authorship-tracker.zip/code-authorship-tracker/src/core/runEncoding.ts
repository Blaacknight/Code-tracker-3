import { AuthorRun, AuthorType } from './types';

/**
 * Encodes an array of AuthorRun to a compact string: "H12,L45,C3"
 */
export function encodeRuns(runs: AuthorRun[]): string {
  return runs.map(r => `${r.author}${r.length}`).join(',');
}

/**
 * Decodes a compact run string back to AuthorRun[].
 */
export function decodeRuns(encoded: string): AuthorRun[] {
  if (!encoded || encoded.trim() === '') { return []; }
  return encoded.split(',').map(segment => {
    const author = segment[0] as AuthorType;
    const length = parseInt(segment.slice(1), 10);
    if (!['H', 'L', 'C'].includes(author) || isNaN(length) || length <= 0) {
      throw new Error(`Invalid run segment: "${segment}"`);
    }
    return { author, length };
  });
}

/**
 * Returns the total character count represented by a run array.
 */
export function totalLength(runs: AuthorRun[]): number {
  return runs.reduce((sum, r) => sum + r.length, 0);
}

/**
 * Compresses adjacent runs with the same author into one run.
 */
export function mergeRuns(runs: AuthorRun[]): AuthorRun[] {
  const merged: AuthorRun[] = [];
  for (const run of runs) {
    if (run.length === 0) { continue; }
    const last = merged[merged.length - 1];
    if (last && last.author === run.author) {
      last.length += run.length;
    } else {
      merged.push({ ...run });
    }
  }
  return merged;
}

/**
 * Expands runs to a flat array of AuthorType per character.
 * Use sparingly on large files.
 */
export function expandRuns(runs: AuthorRun[]): AuthorType[] {
  const result: AuthorType[] = [];
  for (const run of runs) {
    for (let i = 0; i < run.length; i++) {
      result.push(run.author);
    }
  }
  return result;
}

/**
 * Converts a flat AuthorType[] back to merged runs.
 */
export function collapseToRuns(chars: AuthorType[]): AuthorRun[] {
  return mergeRuns(chars.map(a => ({ author: a, length: 1 })));
}

/**
 * Applies a deletion and insertion to a run array.
 * 
 * @param runs        Existing runs
 * @param offset      Character offset where the edit starts
 * @param deleteCount Number of characters removed
 * @param inserted    The AuthorRun[] to insert at offset (after deletion)
 * @returns New merged run array
 */
export function applyEdit(
  runs: AuthorRun[],
  offset: number,
  deleteCount: number,
  inserted: AuthorRun[]
): AuthorRun[] {
  const chars = expandRuns(runs);

  // Clamp bounds
  const safeOffset = Math.max(0, Math.min(offset, chars.length));
  const safeDelete = Math.min(deleteCount, chars.length - safeOffset);

  // Remove deleted characters
  chars.splice(safeOffset, safeDelete);

  // Insert new characters
  const newChars = expandRuns(inserted);
  chars.splice(safeOffset, 0, ...newChars);

  return mergeRuns(collapseToRuns(chars));
}

/**
 * Slices a run array to get the authorship of characters [start, end).
 */
export function sliceRuns(runs: AuthorRun[], start: number, end: number): AuthorRun[] {
  const chars = expandRuns(runs);
  return mergeRuns(collapseToRuns(chars.slice(start, end)));
}

/**
 * Deep clones a run array (simple objects, so JSON round-trip is safe).
 */
export function cloneRuns(runs: AuthorRun[]): AuthorRun[] {
  return runs.map(r => ({ ...r }));
}

/**
 * Shifts all character offsets by inserting `length` characters of `author`
 * at `offset`. Used when lines shift due to upstream changes.
 */
export function insertRuns(
  runs: AuthorRun[],
  offset: number,
  author: AuthorType,
  length: number
): AuthorRun[] {
  return applyEdit(runs, offset, 0, [{ author, length }]);
}

/**
 * Given line-based run data, convert a line+column to a flat offset.
 * Requires the normalized text (with \n line endings).
 */
export function lineColToOffset(text: string, line: number, col: number): number {
  const lines = text.split('\n');
  let offset = 0;
  for (let i = 0; i < line && i < lines.length; i++) {
    offset += lines[i].length + 1; // +1 for \n
  }
  return offset + col;
}
