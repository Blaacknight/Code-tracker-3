/**
 * Core types for the Code Authorship Tracker extension.
 * 
 * Author types:
 *   H = Human (direct keystrokes, IDE autocomplete, formatting)
 *   L = AI/Agentic (multi-char injections, Cline/Copilot blocks)
 *   C = Comment (any code inside comment syntax)
 */

export type AuthorType = 'H' | 'L' | 'C';

/**
 * A run of contiguous characters with the same authorship.
 * Using runs (RLE) keeps the data compact for large files.
 */
export interface AuthorRun {
  author: AuthorType;
  length: number;
}

/**
 * Authorship state for a single file, stored as a flat run-length encoded array.
 * Position 0 = first character of the file (after normalizing line endings to \n).
 */
export interface FileAuthorshipState {
  /** Normalized file path (relative to workspace root) */
  filePath: string;
  /** Content hash at the time of last sync — used to detect external file changes */
  contentHash: string;
  /** Run-length encoded authorship per character */
  runs: AuthorRun[];
  /** Schema version for forward compatibility */
  version: number;
  /** UTC timestamp of last modification */
  lastModified: number;
}

/**
 * A snapshot entry for undo/redo stack.
 */
export interface AuthorshipSnapshot {
  runs: AuthorRun[];
  contentHash: string;
  timestamp: number;
}

/**
 * Per-file undo/redo history.
 */
export interface UndoRedoStack {
  past: AuthorshipSnapshot[];
  future: AuthorshipSnapshot[];
}

/**
 * A single change event captured from VS Code's TextDocumentChangeEvent.
 */
export interface TrackedChange {
  /** Start offset in the normalized document */
  offset: number;
  /** Number of characters removed */
  removedLength: number;
  /** Text that was inserted */
  insertedText: string;
  /** Classification of the inserted text */
  author: AuthorType;
}

/**
 * Clipboard state used for Human-paste detection.
 */
export interface ClipboardEntry {
  text: string;
  /** The active file URI string when the copy happened, if known */
  sourceUri?: string;
  /** Offsets in the source file where this text was copied from */
  sourceOffsets?: number[];
}

/**
 * Report metrics for a single file.
 */
export interface FileReport {
  filePath: string;
  totalChars: number;
  humanChars: number;
  aiChars: number;
  commentChars: number;
  /** Percentage of non-comment code written by humans (0–100) */
  humanPercent: number;
  /** Percentage of non-comment code written by AI (0–100) */
  aiPercent: number;
}

/**
 * Aggregate report for the whole workspace.
 */
export interface WorkspaceReport {
  files: FileReport[];
  totalHumanChars: number;
  totalAiChars: number;
  totalCommentChars: number;
  humanPercent: number;
  aiPercent: number;
  generatedAt: number;
}

/**
 * The on-disk format for a companion authorship file.
 * Stored in .authorship/<relative-path>.auth.json
 */
export interface AuthorshipDiskRecord {
  version: number;
  filePath: string;
  contentHash: string;
  /** Compact run encoding: "H12,L45,C3,H7" */
  runsEncoded: string;
  lastModified: number;
  /** Developer identifier (git user.email or hostname) */
  authorId: string;
}

/**
 * Result of parsing a document's comment regions.
 * A region is [startOffset, endOffset] inclusive.
 */
export type CommentRegion = [number, number];
