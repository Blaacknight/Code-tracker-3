import * as vscode from 'vscode';
import * as path from 'path';
import { AuthorshipStateManager, normalizeText } from './core/stateManager';
import {
  saveAuthorshipState,
  loadAuthorshipState,
  getWorkspaceRoot,
  ensureAuthorshipDir,
  CompanionFileWatcher,
  SourceFileWatcher,
  getCompanionPath,
  repairConflictedCompanion,
} from './sync/persistence';
import {
  generateWorkspaceReport,
  generateFileReport,
  formatReportAsMarkdown,
} from './reporting/reporter';
import {
  AuthorshipDecorations,
  AuthorshipStatusBar,
  applyDecorations,
} from './ui/decorations';
import { ReportWebviewPanel } from './ui/reportPanel';
import * as fs from 'fs';

// ── Globals ──────────────────────────────────────────────────────────────────

let stateManager: AuthorshipStateManager;
let decorations: AuthorshipDecorations;
let statusBar: AuthorshipStatusBar;
let companionWatcher: CompanionFileWatcher;
let sourceWatcher: SourceFileWatcher;

/** Whether decorations are currently visible */
let decorationsEnabled: boolean;

/** Pending save debounce timers per file */
const savePending: Map<string, NodeJS.Timeout> = new Map();

/** Files excluded by glob patterns */
const excludedPatterns: string[] = [];

// ── Extension Activation ─────────────────────────────────────────────────────

export async function activate(context: vscode.ExtensionContext): Promise<void> {
  console.log('[AuthorshipTracker] Activating…');

  stateManager = new AuthorshipStateManager();
  decorations = new AuthorshipDecorations();
  statusBar = new AuthorshipStatusBar();
  companionWatcher = new CompanionFileWatcher();
  sourceWatcher = new SourceFileWatcher();

  decorationsEnabled = vscode.workspace
    .getConfiguration('codeAuthorship')
    .get<boolean>('showDecorations', true);

  const workspaceRoot = getWorkspaceRoot();
  if (workspaceRoot) {
    await ensureAuthorshipDir(workspaceRoot);
    companionWatcher.start(workspaceRoot);
    sourceWatcher.start(workspaceRoot);
  }

  // ── Register Commands ────────────────────────────────────────────────────

  context.subscriptions.push(
    vscode.commands.registerCommand('codeAuthorship.showReport', () => {
      showWorkspaceReport();
    }),

    vscode.commands.registerCommand('codeAuthorship.showFileReport', () => {
      const editor = vscode.window.activeTextEditor;
      if (!editor) { return; }
      showWorkspaceReport(editor.document.uri.fsPath);
    }),

    vscode.commands.registerCommand('codeAuthorship.toggleDecorations', () => {
      decorationsEnabled = !decorationsEnabled;
      vscode.workspace
        .getConfiguration('codeAuthorship')
        .update('showDecorations', decorationsEnabled, vscode.ConfigurationTarget.Global);
      refreshAllDecorations();
      vscode.window.showInformationMessage(
        `Code Authorship decorations ${decorationsEnabled ? 'enabled' : 'disabled'}`
      );
    }),

    vscode.commands.registerCommand('codeAuthorship.resetFile', async () => {
      const editor = vscode.window.activeTextEditor;
      if (!editor) { return; }
      const confirm = await vscode.window.showWarningMessage(
        'Reset authorship for this file? All authorship history will be lost.',
        { modal: true },
        'Reset'
      );
      if (confirm !== 'Reset') { return; }
      const filePath = editor.document.uri.fsPath;
      const content = normalizeText(editor.document.getText());
      stateManager.initializeFile(filePath, content);
      scheduleSave(filePath);
      refreshDecorations(editor);
      statusBar.update(stateManager.getState(filePath));
      vscode.window.showInformationMessage('File authorship reset to Human.');
    }),

    vscode.commands.registerCommand('codeAuthorship.syncNow', async () => {
      const workspaceRoot = getWorkspaceRoot();
      if (!workspaceRoot) {
        vscode.window.showErrorMessage('No workspace folder open.');
        return;
      }
      await syncAll(workspaceRoot);
      vscode.window.showInformationMessage('Authorship data synced.');
    })
  );

  // ── Document Events ──────────────────────────────────────────────────────

  // Track undo/redo state
  let lastChangeReason: vscode.TextDocumentChangeReason | undefined;

  context.subscriptions.push(
    vscode.workspace.onDidChangeTextDocument(event => {
      if (event.contentChanges.length === 0) { return; }
      if (isExcluded(event.document.uri.fsPath)) { return; }

      const isUndoRedo =
        event.reason === vscode.TextDocumentChangeReason.Undo ||
        event.reason === vscode.TextDocumentChangeReason.Redo;

      stateManager.handleDocumentChange(event, isUndoRedo);

      const editor = vscode.window.visibleTextEditors.find(
        e => e.document === event.document
      );
      if (editor) {
        refreshDecorations(editor);
      }

      const state = stateManager.getState(event.document.uri.fsPath);
      statusBar.update(state);

      // Debounce saves
      scheduleSave(event.document.uri.fsPath);
    }),

    vscode.workspace.onDidOpenTextDocument(document => {
      if (isExcluded(document.uri.fsPath)) { return; }
      initializeDocument(document);
    }),

    vscode.workspace.onDidSaveTextDocument(document => {
      if (isExcluded(document.uri.fsPath)) { return; }
      stateManager.handleDocumentSave(document);
      sourceWatcher.markSaving(document.uri.fsPath);

      const workspaceRoot = getWorkspaceRoot();
      const state = stateManager.getState(document.uri.fsPath);
      if (workspaceRoot && state) {
        saveAuthorshipState(state, workspaceRoot).catch(console.error);
      }
    }),

    vscode.workspace.onDidCloseTextDocument(document => {
      stateManager.removeFile(document.uri.fsPath);
    })
  );

  // ── Editor Events ────────────────────────────────────────────────────────

  context.subscriptions.push(
    vscode.window.onDidChangeActiveTextEditor(editor => {
      if (!editor) {
        statusBar.hide();
        return;
      }
      if (isExcluded(editor.document.uri.fsPath)) {
        statusBar.hide();
        return;
      }
      if (!stateManager.getState(editor.document.uri.fsPath)) {
        initializeDocument(editor.document);
      }
      refreshDecorations(editor);
      statusBar.update(stateManager.getState(editor.document.uri.fsPath));
    }),

    vscode.window.onDidChangeVisibleTextEditors(editors => {
      for (const editor of editors) {
        if (isExcluded(editor.document.uri.fsPath)) { continue; }
        if (!stateManager.getState(editor.document.uri.fsPath)) {
          initializeDocument(editor.document);
        }
        refreshDecorations(editor);
      }
    })
  );

  // ── Clipboard Tracking ───────────────────────────────────────────────────

  // We hook into the copy command to record clipboard content
  context.subscriptions.push(
    vscode.commands.registerCommand('editor.action.clipboardCopyAction', async () => {
      const editor = vscode.window.activeTextEditor;
      if (editor && editor.selection && !editor.selection.isEmpty) {
        const selectedText = editor.document.getText(editor.selection);
        stateManager.recordCopy(selectedText, editor.document.uri.toString());
      }
      // Execute the original copy action
      await vscode.commands.executeCommand('execCommandId', 'editor.action.clipboardCopyAction');
    })
  );

  // ── External File Change Handling ────────────────────────────────────────

  sourceWatcher.onExternalChange(async (uri) => {
    if (isExcluded(uri.fsPath)) { return; }
    const workspaceRoot = getWorkspaceRoot();
    if (!workspaceRoot) { return; }

    // Check if there's an open document for this file
    const openDoc = vscode.workspace.textDocuments.find(
      d => d.uri.fsPath === uri.fsPath
    );
    if (!openDoc) { return; }

    // Load saved authorship data for this file
    const saved = loadAuthorshipState(uri.fsPath, workspaceRoot);
    const content = openDoc.getText();

    stateManager.beginExternalReload(uri.fsPath);
    try {
      stateManager.handleExternalFileChange(
        uri.fsPath,
        content,
        saved?.runs,
        saved?.hash
      );
    } finally {
      stateManager.endExternalReload(uri.fsPath);
    }

    // Refresh decorations
    const editor = vscode.window.visibleTextEditors.find(
      e => e.document.uri.fsPath === uri.fsPath
    );
    if (editor) { refreshDecorations(editor); }
    statusBar.update(stateManager.getState(uri.fsPath));
  });

  // ── Companion File Change Handling (git pull updated another dev's data) ─

  companionWatcher.onCompanionChanged(async (companionPath) => {
    // Try to find the source file this companion belongs to
    const workspaceRoot = getWorkspaceRoot();
    if (!workspaceRoot) { return; }

    // Detect and repair conflict markers
    try {
      const raw = fs.readFileSync(companionPath, 'utf8');
      if (raw.includes('<<<<<<<')) {
        const repaired = repairConflictedCompanion(raw);
        if (repaired) {
          fs.writeFileSync(companionPath, repaired, 'utf8');
        }
      }
    } catch { /* ignore */ }
  });

  // ── Configuration Changes ────────────────────────────────────────────────

  context.subscriptions.push(
    vscode.workspace.onDidChangeConfiguration(e => {
      if (e.affectsConfiguration('codeAuthorship.showDecorations')) {
        decorationsEnabled = vscode.workspace
          .getConfiguration('codeAuthorship')
          .get<boolean>('showDecorations', true);
        refreshAllDecorations();
      }
    })
  );

  // ── Initialize Open Documents ────────────────────────────────────────────

  for (const document of vscode.workspace.textDocuments) {
    if (!isExcluded(document.uri.fsPath)) {
      initializeDocument(document);
    }
  }

  for (const editor of vscode.window.visibleTextEditors) {
    if (!isExcluded(editor.document.uri.fsPath)) {
      refreshDecorations(editor);
    }
  }

  const activeEditor = vscode.window.activeTextEditor;
  if (activeEditor) {
    statusBar.update(stateManager.getState(activeEditor.document.uri.fsPath));
  }

  // ── Register Disposables ─────────────────────────────────────────────────

  context.subscriptions.push(
    decorations,
    statusBar,
    companionWatcher,
    sourceWatcher,
    stateManager.onStateChanged(() => {
      // Debounced auto-save on state change
    })
  );

  console.log('[AuthorshipTracker] Active.');
}

export function deactivate(): void {
  // Flush any pending saves
  for (const [filePath, timer] of savePending) {
    clearTimeout(timer);
    const workspaceRoot = getWorkspaceRoot();
    const state = stateManager.getState(filePath);
    if (workspaceRoot && state) {
      saveAuthorshipState(state, workspaceRoot).catch(console.error);
    }
  }
  savePending.clear();
}

// ── Helper Functions ─────────────────────────────────────────────────────────

/**
 * Initializes or reloads authorship state for a document.
 */
function initializeDocument(document: vscode.TextDocument): void {
  if (document.uri.scheme !== 'file') { return; }
  const filePath = document.uri.fsPath;
  const workspaceRoot = getWorkspaceRoot();

  let savedRuns = undefined;
  let savedHash = undefined;

  if (workspaceRoot) {
    const saved = loadAuthorshipState(filePath, workspaceRoot);
    if (saved) {
      savedRuns = saved.runs;
      savedHash = saved.hash;
    }
  }

  stateManager.initializeFile(
    filePath,
    document.getText(),
    savedRuns,
    savedHash
  );
}

/**
 * Refreshes decorations for a single editor.
 */
function refreshDecorations(editor: vscode.TextEditor): void {
  const state = stateManager.getState(editor.document.uri.fsPath);
  applyDecorations(editor, state!, decorations, decorationsEnabled && !!state);
}

/**
 * Refreshes decorations for all visible editors.
 */
function refreshAllDecorations(): void {
  for (const editor of vscode.window.visibleTextEditors) {
    refreshDecorations(editor);
  }
}

/**
 * Schedules a debounced save for a file (500ms after last change).
 */
function scheduleSave(filePath: string): void {
  const syncOnSave = vscode.workspace
    .getConfiguration('codeAuthorship')
    .get<boolean>('syncOnSave', true);
  if (!syncOnSave) { return; }

  const existing = savePending.get(filePath);
  if (existing) { clearTimeout(existing); }

  const timer = setTimeout(async () => {
    savePending.delete(filePath);
    const workspaceRoot = getWorkspaceRoot();
    const state = stateManager.getState(filePath);
    if (workspaceRoot && state) {
      try {
        await saveAuthorshipState(state, workspaceRoot);
      } catch (err) {
        console.error(`[AuthorshipTracker] Save failed for ${filePath}:`, err);
      }
    }
  }, 500);

  savePending.set(filePath, timer);
}

/**
 * Syncs all tracked files to disk.
 */
async function syncAll(workspaceRoot: string): Promise<void> {
  for (const filePath of stateManager.getTrackedFiles()) {
    const state = stateManager.getState(filePath);
    if (state) {
      await saveAuthorshipState(state, workspaceRoot).catch(console.error);
    }
  }
}

/**
 * Shows the workspace authorship report in a webview.
 */
function showWorkspaceReport(focusFile?: string): void {
  const states = stateManager
    .getTrackedFiles()
    .map(f => stateManager.getState(f))
    .filter(Boolean) as any[];

  if (states.length === 0) {
    vscode.window.showInformationMessage(
      'No files are being tracked yet. Open some files first.'
    );
    return;
  }

  const report = generateWorkspaceReport(states);
  const extensionUri = vscode.Uri.file(''); // placeholder
  ReportWebviewPanel.createOrShow(extensionUri, report);
}

/**
 * Checks if a file path matches any exclusion pattern.
 */
function isExcluded(filePath: string): boolean {
  const patterns = vscode.workspace
    .getConfiguration('codeAuthorship')
    .get<string[]>('excludePatterns', ['**/node_modules/**', '**/.git/**', '**/dist/**']);

  for (const pattern of patterns) {
    // Simple glob matching for common patterns
    const regex = globToRegex(pattern);
    if (regex.test(filePath.replace(/\\/g, '/'))) {
      return true;
    }
  }

  // Also exclude companion files themselves
  if (filePath.includes('.authorship')) { return true; }

  return false;
}

/**
 * Converts a simple glob pattern to a RegExp.
 */
function globToRegex(glob: string): RegExp {
  const escaped = glob
    .replace(/\./g, '\\.')
    .replace(/\*\*/g, '§§§')
    .replace(/\*/g, '[^/]*')
    .replace(/§§§/g, '.*');
  return new RegExp(escaped);
}
