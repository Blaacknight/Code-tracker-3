/**
 * Unit tests for Code Authorship Tracker core logic.
 * Run with: npx ts-node src/test/suite.ts
 *
 * These tests don't require VS Code — they test pure TypeScript logic.
 */

import {
  encodeRuns,
  decodeRuns,
  mergeRuns,
  applyEdit,
  totalLength,
  expandRuns,
  sliceRuns,
} from '../core/runEncoding';
import { findCommentRegions, buildCommentMap } from '../core/commentDetector';
import { AuthorRun, AuthorType } from '../core/types';

// ── Simple test harness ───────────────────────────────────────────────────────

let passed = 0;
let failed = 0;

function assert(condition: boolean, name: string, message?: string): void {
  if (condition) {
    console.log(`  ✓ ${name}`);
    passed++;
  } else {
    console.error(`  ✗ ${name}${message ? ': ' + message : ''}`);
    failed++;
  }
}

function assertEqual<T>(actual: T, expected: T, name: string): void {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  assert(ok, name, ok ? '' : `\n    expected: ${JSON.stringify(expected)}\n    actual:   ${JSON.stringify(actual)}`);
}

function describe(suiteName: string, fn: () => void): void {
  console.log(`\n── ${suiteName} ──`);
  fn();
}

// ── Run Length Encoding ───────────────────────────────────────────────────────

describe('Run Encoding', () => {
  const runs: AuthorRun[] = [
    { author: 'H', length: 10 },
    { author: 'L', length: 5 },
    { author: 'C', length: 3 },
  ];

  const encoded = encodeRuns(runs);
  assertEqual(encoded, 'H10,L5,C3', 'encodeRuns produces correct string');

  const decoded = decodeRuns(encoded);
  assertEqual(decoded, runs, 'decodeRuns round-trips correctly');

  const merged = mergeRuns([
    { author: 'H', length: 5 },
    { author: 'H', length: 3 },
    { author: 'L', length: 2 },
    { author: 'L', length: 0 },
    { author: 'C', length: 1 },
  ]);
  assertEqual(merged, [
    { author: 'H', length: 8 },
    { author: 'L', length: 2 },
    { author: 'C', length: 1 },
  ], 'mergeRuns collapses adjacent same-author runs and removes zero-length');

  assertEqual(totalLength(runs), 18, 'totalLength sums correctly');

  const expanded = expandRuns([{ author: 'H', length: 3 }, { author: 'L', length: 2 }]);
  assertEqual(expanded, ['H', 'H', 'H', 'L', 'L'], 'expandRuns produces correct flat array');
});

// ── applyEdit ─────────────────────────────────────────────────────────────────

describe('applyEdit', () => {
  const base: AuthorRun[] = [{ author: 'H', length: 10 }];

  // Insert at offset 5
  const afterInsert = applyEdit(base, 5, 0, [{ author: 'L', length: 3 }]);
  assertEqual(totalLength(afterInsert), 13, 'Insert: total length grows by 3');
  assertEqual(afterInsert, [
    { author: 'H', length: 5 },
    { author: 'L', length: 3 },
    { author: 'H', length: 5 },
  ], 'Insert splits run correctly');

  // Delete 3 chars at offset 2
  const afterDelete = applyEdit(base, 2, 3, []);
  assertEqual(totalLength(afterDelete), 7, 'Delete: total length shrinks by 3');
  assertEqual(afterDelete, [{ author: 'H', length: 7 }], 'Delete from same-author run merges correctly');

  // Replace: delete 2, insert 5
  const base2: AuthorRun[] = [
    { author: 'H', length: 5 },
    { author: 'L', length: 5 },
  ];
  const afterReplace = applyEdit(base2, 3, 4, [{ author: 'L', length: 6 }]);
  assertEqual(totalLength(afterReplace), 12, 'Replace: length adjusted correctly');

  // Edge case: insert at start
  const atStart = applyEdit(base, 0, 0, [{ author: 'L', length: 2 }]);
  assertEqual(atStart[0], { author: 'L', length: 2 }, 'Insert at start places L first');

  // Edge case: insert at end
  const atEnd = applyEdit(base, 10, 0, [{ author: 'L', length: 2 }]);
  assertEqual(atEnd[atEnd.length - 1], { author: 'L', length: 2 }, 'Insert at end appends correctly');

  // Multi-cursor simulation: two non-overlapping inserts
  let multiCursor: AuthorRun[] = [{ author: 'H', length: 20 }];
  multiCursor = applyEdit(multiCursor, 0, 0, [{ author: 'L', length: 3 }]);  // insert at 0
  multiCursor = applyEdit(multiCursor, 13, 0, [{ author: 'L', length: 3 }]); // insert at 10+3
  assertEqual(totalLength(multiCursor), 26, 'Multi-cursor: total length correct');
});

// ── sliceRuns ─────────────────────────────────────────────────────────────────

describe('sliceRuns', () => {
  const runs: AuthorRun[] = [
    { author: 'H', length: 5 },
    { author: 'L', length: 5 },
    { author: 'C', length: 5 },
  ];

  const slice = sliceRuns(runs, 3, 12);
  assertEqual(totalLength(slice), 9, 'sliceRuns returns correct length');
  assertEqual(slice[0], { author: 'H', length: 2 }, 'sliceRuns first segment correct');
  assertEqual(slice[1], { author: 'L', length: 5 }, 'sliceRuns middle segment correct');
  assertEqual(slice[2], { author: 'C', length: 2 }, 'sliceRuns last segment correct');
});

// ── Comment Detection ─────────────────────────────────────────────────────────

describe('Comment Detection - TypeScript', () => {
  const ts = `
// Single line comment
const x = 1;
/* Block comment
   spanning multiple lines */
const y = 2; // inline comment
/**
 * JSDoc comment
 */
function foo() {}
`.trim();

  const regions = findCommentRegions(ts, 'typescript');
  assert(regions.length > 0, 'Finds comment regions in TypeScript');

  // Verify that the line comment region starts at offset 0
  const firstRegion = regions[0];
  assert(
    ts.slice(firstRegion[0], firstRegion[1] + 1).startsWith('//'),
    'First region starts with //'
  );

  const map = buildCommentMap(ts, 'typescript');
  assert(map[0] === true, 'First char (/) is in comment');
  assert(map[1] === true, 'Second char (/) is in comment');

  // 'const x = 1' should NOT be a comment
  const constXOffset = ts.indexOf('const x');
  assert(constXOffset > 0, 'Found "const x" in text');
  assert(map[constXOffset] === false, '"const" is not in a comment');
});

describe('Comment Detection - Python', () => {
  const py = `
# Python comment
x = 1
"""
Docstring block
"""
y = 2
`.trim();

  const regions = findCommentRegions(py, 'python');
  assert(regions.length >= 2, 'Finds at least 2 comment regions in Python');

  const map = buildCommentMap(py, 'python');
  assert(map[0] === true, 'Python # comment detected at start');

  const xOffset = py.indexOf('x = 1');
  assert(map[xOffset] === false, 'x = 1 is not a comment');
});

describe('Comment Detection - HTML', () => {
  const html = `<div><!-- HTML comment --></div>`;
  const regions = findCommentRegions(html, 'html');
  assert(regions.length === 1, 'Finds 1 HTML comment region');
  const [start, end] = regions[0];
  assertEqual(html.slice(start, start + 4), '<!--', 'Region starts with <!--');
  assertEqual(html.slice(end - 2, end + 1), '-->', 'Region ends with -->');
});

describe('Comment Detection - No false positives in strings', () => {
  const js = `const s = "http://not-a-comment.com"; const n = 1;`;
  const map = buildCommentMap(js, 'javascript');
  const urlOffset = js.indexOf('http');
  // The :// in the URL should not trigger comment detection
  assert(map[urlOffset] === false, 'URL inside string not treated as comment');
});

// ── encodeRuns error handling ─────────────────────────────────────────────────

describe('Encode/Decode Errors', () => {
  let threw = false;
  try {
    decodeRuns('X99'); // Invalid author
  } catch {
    threw = true;
  }
  assert(threw, 'decodeRuns throws on invalid author type');

  assertEqual(decodeRuns(''), [], 'decodeRuns returns empty array for empty string');
});

// ── Summary ───────────────────────────────────────────────────────────────────

console.log(`\n${'─'.repeat(40)}`);
console.log(`Tests: ${passed + failed} total, ${passed} passed, ${failed} failed`);
if (failed > 0) {
  process.exit(1);
}
