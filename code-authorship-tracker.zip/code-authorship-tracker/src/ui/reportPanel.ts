import * as vscode from 'vscode';
import { WorkspaceReport, FileReport } from '../core/types';
import { getAiRatioColor } from '../reporting/reporter';

/**
 * Creates and manages the authorship report webview panel.
 */
export class ReportWebviewPanel {
  private static currentPanel: ReportWebviewPanel | undefined;
  private readonly panel: vscode.WebviewPanel;
  private _disposables: vscode.Disposable[] = [];

  public static createOrShow(
    extensionUri: vscode.Uri,
    report: WorkspaceReport
  ): void {
    if (ReportWebviewPanel.currentPanel) {
      ReportWebviewPanel.currentPanel.panel.reveal(vscode.ViewColumn.Two);
      ReportWebviewPanel.currentPanel.update(report);
      return;
    }

    const panel = vscode.window.createWebviewPanel(
      'codeAuthorshipReport',
      'Code Authorship Report',
      vscode.ViewColumn.Two,
      {
        enableScripts: true,
        retainContextWhenHidden: true,
      }
    );

    ReportWebviewPanel.currentPanel = new ReportWebviewPanel(panel, report);
  }

  private constructor(panel: vscode.WebviewPanel, report: WorkspaceReport) {
    this.panel = panel;
    this.update(report);

    this.panel.onDidDispose(() => this.dispose(), null, this._disposables);
  }

  public update(report: WorkspaceReport): void {
    this.panel.webview.html = this.getHtml(report);
  }

  public dispose(): void {
    ReportWebviewPanel.currentPanel = undefined;
    this.panel.dispose();
    for (const d of this._disposables) { d.dispose(); }
    this._disposables = [];
  }

  private getHtml(report: WorkspaceReport): string {
    const date = new Date(report.generatedAt).toLocaleString();
    const aiColor = getAiRatioColor(report.aiPercent);
    const humanColor = '#4caf50';

    const fileRows = report.files
      .filter(f => f.humanChars + f.aiChars > 0)
      .map(f => this.renderFileRow(f))
      .join('\n');

    return /* html */`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Code Authorship Report</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;700&family=Syne:wght@400;600;800&display=swap');

  :root {
    --human: #4caf50;
    --ai: #2196f3;
    --comment: #9e9e9e;
    --bg: #0d1117;
    --surface: #161b22;
    --border: #30363d;
    --text: #e6edf3;
    --text-muted: #7d8590;
    --accent: #58a6ff;
  }

  * { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    font-family: 'JetBrains Mono', monospace;
    background: var(--bg);
    color: var(--text);
    padding: 2rem;
    min-height: 100vh;
  }

  header {
    margin-bottom: 2rem;
    border-bottom: 1px solid var(--border);
    padding-bottom: 1.5rem;
  }

  h1 {
    font-family: 'Syne', sans-serif;
    font-size: 1.8rem;
    font-weight: 800;
    letter-spacing: -0.02em;
    color: var(--text);
    margin-bottom: 0.25rem;
  }

  .subtitle {
    font-size: 0.75rem;
    color: var(--text-muted);
  }

  .overview {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    gap: 1rem;
    margin-bottom: 2rem;
  }

  .stat-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 1.25rem;
    position: relative;
    overflow: hidden;
  }

  .stat-card::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 3px;
  }

  .stat-card.human::before { background: var(--human); }
  .stat-card.ai::before { background: var(--ai); }
  .stat-card.comment::before { background: var(--comment); }

  .stat-label {
    font-size: 0.65rem;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: var(--text-muted);
    margin-bottom: 0.5rem;
  }

  .stat-value {
    font-family: 'Syne', sans-serif;
    font-size: 2.5rem;
    font-weight: 800;
    line-height: 1;
  }

  .stat-card.human .stat-value { color: var(--human); }
  .stat-card.ai .stat-value { color: var(--ai); }
  .stat-card.comment .stat-value { color: var(--comment); }

  .stat-sub {
    font-size: 0.7rem;
    color: var(--text-muted);
    margin-top: 0.4rem;
  }

  .big-bar {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 1.25rem;
    margin-bottom: 2rem;
  }

  .big-bar h2 {
    font-family: 'Syne', sans-serif;
    font-size: 0.8rem;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: var(--text-muted);
    margin-bottom: 1rem;
    font-weight: 600;
  }

  .ratio-bar {
    height: 20px;
    border-radius: 4px;
    overflow: hidden;
    display: flex;
    margin-bottom: 0.5rem;
  }

  .ratio-human {
    background: var(--human);
    height: 100%;
    transition: width 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.65rem;
    font-weight: 700;
    color: #000;
  }

  .ratio-ai {
    background: var(--ai);
    height: 100%;
    transition: width 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.65rem;
    font-weight: 700;
    color: #fff;
  }

  .bar-labels {
    display: flex;
    justify-content: space-between;
    font-size: 0.65rem;
    color: var(--text-muted);
  }

  h2.section-title {
    font-family: 'Syne', sans-serif;
    font-size: 1rem;
    font-weight: 700;
    margin-bottom: 1rem;
    color: var(--text);
  }

  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.75rem;
  }

  thead th {
    text-align: left;
    padding: 0.5rem 0.75rem;
    color: var(--text-muted);
    font-size: 0.65rem;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    border-bottom: 1px solid var(--border);
    font-weight: 400;
  }

  tbody tr {
    border-bottom: 1px solid rgba(48, 54, 61, 0.5);
    transition: background 0.15s;
  }

  tbody tr:hover {
    background: rgba(255,255,255,0.03);
  }

  tbody td {
    padding: 0.6rem 0.75rem;
    vertical-align: middle;
  }

  .file-name {
    font-family: 'JetBrains Mono', monospace;
    font-size: 0.72rem;
    color: var(--accent);
    max-width: 300px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .mini-bar {
    width: 100px;
    height: 6px;
    border-radius: 3px;
    overflow: hidden;
    display: flex;
    background: var(--border);
  }

  .mini-human { background: var(--human); height: 100%; }
  .mini-ai { background: var(--ai); height: 100%; }

  .pct-human { color: var(--human); font-weight: 600; }
  .pct-ai { color: var(--ai); font-weight: 600; }
  .pct-comment { color: var(--comment); }

  .badge {
    display: inline-block;
    padding: 0.1rem 0.4rem;
    border-radius: 999px;
    font-size: 0.6rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }

  .badge-h { background: rgba(76,175,80,0.2); color: var(--human); }
  .badge-l { background: rgba(33,150,243,0.2); color: var(--ai); }

  .legend {
    display: flex;
    gap: 1.5rem;
    font-size: 0.65rem;
    color: var(--text-muted);
    margin-bottom: 1.5rem;
  }

  .legend-dot {
    width: 8px; height: 8px;
    border-radius: 50%;
    display: inline-block;
    margin-right: 0.35rem;
    vertical-align: middle;
  }
</style>
</head>
<body>
<header>
  <h1>Code Authorship Report</h1>
  <div class="subtitle">Generated ${date} &nbsp;·&nbsp; Excludes comments from ratio</div>
</header>

<div class="overview">
  <div class="stat-card human">
    <div class="stat-label">🧑 Human</div>
    <div class="stat-value">${report.humanPercent}%</div>
    <div class="stat-sub">${report.totalHumanChars.toLocaleString()} chars</div>
  </div>
  <div class="stat-card ai">
    <div class="stat-label">🤖 AI / Agentic</div>
    <div class="stat-value">${report.aiPercent}%</div>
    <div class="stat-sub">${report.totalAiChars.toLocaleString()} chars</div>
  </div>
  <div class="stat-card comment">
    <div class="stat-label">💬 Comments</div>
    <div class="stat-value">—</div>
    <div class="stat-sub">${report.totalCommentChars.toLocaleString()} chars (excluded)</div>
  </div>
</div>

<div class="big-bar">
  <h2>Workspace Composition</h2>
  <div class="ratio-bar">
    <div class="ratio-human" style="width:${report.humanPercent}%">
      ${report.humanPercent > 10 ? report.humanPercent + '%' : ''}
    </div>
    <div class="ratio-ai" style="width:${report.aiPercent}%">
      ${report.aiPercent > 10 ? report.aiPercent + '%' : ''}
    </div>
  </div>
  <div class="bar-labels">
    <span><span class="legend-dot" style="background:var(--human)"></span>Human</span>
    <span><span class="legend-dot" style="background:var(--ai)"></span>AI</span>
  </div>
</div>

<h2 class="section-title">By File</h2>
<div class="legend">
  <span><span class="legend-dot" style="background:var(--human)"></span>Human (H)</span>
  <span><span class="legend-dot" style="background:var(--ai)"></span>AI/Agentic (L)</span>
  <span><span class="legend-dot" style="background:var(--comment)"></span>Comment (C, excluded from %)</span>
</div>

<table>
  <thead>
    <tr>
      <th>File</th>
      <th>Mix</th>
      <th>Human %</th>
      <th>AI %</th>
      <th>H chars</th>
      <th>L chars</th>
      <th>C chars</th>
    </tr>
  </thead>
  <tbody>
    ${fileRows}
  </tbody>
</table>

</body>
</html>`;
  }

  private renderFileRow(f: FileReport): string {
    const code = f.humanChars + f.aiChars;
    const hWidth = code > 0 ? (f.humanChars / code) * 100 : 0;
    const lWidth = code > 0 ? (f.aiChars / code) * 100 : 0;
    const name = f.filePath.split(/[/\\]/).pop() ?? f.filePath;
    const dominant = f.aiChars > f.humanChars ? 'L' : 'H';

    return `<tr>
      <td>
        <span class="badge ${dominant === 'L' ? 'badge-l' : 'badge-h'}">${dominant}</span>
        &nbsp;<span class="file-name" title="${f.filePath}">${name}</span>
      </td>
      <td>
        <div class="mini-bar">
          <div class="mini-human" style="width:${hWidth}%"></div>
          <div class="mini-ai" style="width:${lWidth}%"></div>
        </div>
      </td>
      <td class="pct-human">${f.humanPercent}%</td>
      <td class="pct-ai">${f.aiPercent}%</td>
      <td>${f.humanChars.toLocaleString()}</td>
      <td>${f.aiChars.toLocaleString()}</td>
      <td class="pct-comment">${f.commentChars.toLocaleString()}</td>
    </tr>`;
  }
}
