import * as vscode from 'vscode';
import { FileAuthorshipState, AuthorType } from '../core/types';
import { expandRuns } from '../core/runEncoding';
import { normalizeText } from '../core/stateManager';

/**
 * Decoration types for each authorship category.
 */
export class AuthorshipDecorations {
  public readonly humanDecoration: vscode.TextEditorDecorationType;
  public readonly aiDecoration: vscode.TextEditorDecorationType;
  public readonly commentDecoration: vscode.TextEditorDecorationType;

  constructor() {
    this.humanDecoration = vscode.window.createTextEditorDecorationType({
      // Subtle left border for human code
      borderWidth: '0 0 0 2px',
      borderStyle: 'solid',
      borderColor: 'rgba(76, 175, 80, 0.6)',
      overviewRulerColor: 'rgba(76, 175, 80, 0.4)',
      overviewRulerLane: vscode.OverviewRulerLane.Left,
    });

    this.aiDecoration = vscode.window.createTextEditorDecorationType({
      // More prominent border for AI code
      borderWidth: '0 0 0 2px',
      borderStyle: 'solid',
      borderColor: 'rgba(33, 150, 243, 0.8)',
      backgroundColor: 'rgba(33, 150, 243, 0.05)',
      overviewRulerColor: 'rgba(33, 150, 243, 0.5)',
      overviewRulerLane: vscode.OverviewRulerLane.Left,
    });

    this.commentDecoration = vscode.window.createTextEditorDecorationType({
      // Faint styling for comments
      opacity: '0.7',
    });
  }

  public dispose(): void {
    this.humanDecoration.dispose();
    this.aiDecoration.dispose();
    this.commentDecoration.dispose();
  }
}

/**
 * Applies authorship decorations to an editor.
 */
export function applyDecorations(
  editor: vscode.TextEditor,
  state: FileAuthorshipState,
  decorations: AuthorshipDecorations,
  enabled: boolean
): void {
  if (!enabled) {
    editor.setDecorations(decorations.humanDecoration, []);
    editor.setDecorations(decorations.aiDecoration, []);
    editor.setDecorations(decorations.commentDecoration, []);
    return;
  }

  const document = editor.document;
  const text = normalizeText(document.getText());

  // Build ranges per author type using line-level granularity
  // (character-level decorations cause performance issues on large files)
  const lineAuthors = computeLineAuthors(state, text);

  const humanRanges: vscode.Range[] = [];
  const aiRanges: vscode.Range[] = [];
  const commentRanges: vscode.Range[] = [];

  for (let lineIdx = 0; lineIdx < lineAuthors.length; lineIdx++) {
    const dominant = lineAuthors[lineIdx];
    if (dominant === null) { continue; }

    const lineCount = document.lineCount;
    if (lineIdx >= lineCount) { break; }

    const line = document.lineAt(lineIdx);
    const range = new vscode.Range(
      new vscode.Position(lineIdx, 0),
      new vscode.Position(lineIdx, line.text.length)
    );

    if (dominant === 'H') { humanRanges.push(range); }
    else if (dominant === 'L') { aiRanges.push(range); }
    else if (dominant === 'C') { commentRanges.push(range); }
  }

  editor.setDecorations(decorations.humanDecoration, humanRanges);
  editor.setDecorations(decorations.aiDecoration, aiRanges);
  editor.setDecorations(decorations.commentDecoration, commentRanges);
}

/**
 * Computes the dominant author type per line.
 * Returns null for empty lines.
 */
function computeLineAuthors(
  state: FileAuthorshipState,
  text: string
): Array<AuthorType | null> {
  const lines = text.split('\n');
  const chars = expandRuns(state.runs);
  const lineAuthors: Array<AuthorType | null> = [];

  let offset = 0;
  for (const line of lines) {
    if (line.length === 0) {
      lineAuthors.push(null);
      offset += 1; // skip \n
      continue;
    }

    // Count authors for this line's non-whitespace characters
    const counts: Record<AuthorType, number> = { H: 0, L: 0, C: 0 };
    for (let i = 0; i < line.length; i++) {
      if (line[i] !== ' ' && line[i] !== '\t') {
        const author = chars[offset + i] ?? 'H';
        counts[author]++;
      }
    }
    offset += line.length + 1; // +1 for \n

    // Dominant author wins (Comments don't override H/L dominance unless all comment)
    const total = counts.H + counts.L + counts.C;
    if (total === 0) {
      lineAuthors.push(null);
    } else if (counts.C === total) {
      lineAuthors.push('C');
    } else if (counts.L > counts.H) {
      lineAuthors.push('L');
    } else {
      lineAuthors.push('H');
    }
  }

  return lineAuthors;
}

/**
 * Creates a status bar item showing file-level authorship summary.
 */
export class AuthorshipStatusBar {
  private item: vscode.StatusBarItem;

  constructor() {
    this.item = vscode.window.createStatusBarItem(
      vscode.StatusBarAlignment.Right,
      100
    );
    this.item.command = 'codeAuthorship.showFileReport';
    this.item.tooltip = 'Click to see full authorship report';
  }

  public update(state: FileAuthorshipState | undefined): void {
    if (!state) {
      this.item.text = '$(person) Authorship: N/A';
      this.item.show();
      return;
    }

    let H = 0, L = 0, C = 0;
    for (const run of state.runs) {
      if (run.author === 'H') { H += run.length; }
      else if (run.author === 'L') { L += run.length; }
      else { C += run.length; }
    }

    const code = H + L;
    if (code === 0) {
      this.item.text = '$(person) 🧑 —% 🤖 —%';
      this.item.show();
      return;
    }

    const hPct = Math.round((H / code) * 100);
    const lPct = Math.round((L / code) * 100);

    this.item.text = `🧑 ${hPct}% 🤖 ${lPct}%`;
    this.item.backgroundColor = lPct > 70
      ? new vscode.ThemeColor('statusBarItem.warningBackground')
      : undefined;
    this.item.show();
  }

  public hide(): void {
    this.item.hide();
  }

  public dispose(): void {
    this.item.dispose();
  }
}
