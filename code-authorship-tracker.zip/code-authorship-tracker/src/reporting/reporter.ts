import { FileAuthorshipState, FileReport, WorkspaceReport, AuthorRun } from '../core/types';
import { totalLength } from '../core/runEncoding';

/**
 * Computes the authorship breakdown for a single file's runs.
 */
function countRunsByType(runs: AuthorRun[]): { H: number; L: number; C: number } {
  const counts = { H: 0, L: 0, C: 0 };
  for (const run of runs) {
    counts[run.author] += run.length;
  }
  return counts;
}

/**
 * Generates a FileReport for a single file.
 */
export function generateFileReport(state: FileAuthorshipState): FileReport {
  const counts = countRunsByType(state.runs);
  const codeChars = counts.H + counts.L; // excludes comments

  const humanPercent = codeChars > 0 ? Math.round((counts.H / codeChars) * 1000) / 10 : 0;
  const aiPercent = codeChars > 0 ? Math.round((counts.L / codeChars) * 1000) / 10 : 0;

  return {
    filePath: state.filePath,
    totalChars: totalLength(state.runs),
    humanChars: counts.H,
    aiChars: counts.L,
    commentChars: counts.C,
    humanPercent,
    aiPercent,
  };
}

/**
 * Generates an aggregate WorkspaceReport from multiple file states.
 */
export function generateWorkspaceReport(states: FileAuthorshipState[]): WorkspaceReport {
  let totalH = 0, totalL = 0, totalC = 0;
  const files: FileReport[] = [];

  for (const state of states) {
    const report = generateFileReport(state);
    files.push(report);
    totalH += report.humanChars;
    totalL += report.aiChars;
    totalC += report.commentChars;
  }

  const codeChars = totalH + totalL;
  const humanPercent = codeChars > 0 ? Math.round((totalH / codeChars) * 1000) / 10 : 0;
  const aiPercent = codeChars > 0 ? Math.round((totalL / codeChars) * 1000) / 10 : 0;

  return {
    files: files.sort((a, b) => b.aiChars - a.aiChars),
    totalHumanChars: totalH,
    totalAiChars: totalL,
    totalCommentChars: totalC,
    humanPercent,
    aiPercent,
    generatedAt: Date.now(),
  };
}

/**
 * Formats a WorkspaceReport as a Markdown table string.
 */
export function formatReportAsMarkdown(report: WorkspaceReport): string {
  const date = new Date(report.generatedAt).toLocaleString();
  const lines: string[] = [
    '# Code Authorship Report',
    '',
    `**Generated:** ${date}`,
    `**Workspace Totals (excluding comments):**`,
    `- 🧑 Human: ${report.humanPercent}% (${report.totalHumanChars.toLocaleString()} chars)`,
    `- 🤖 AI: ${report.aiPercent}% (${report.totalAiChars.toLocaleString()} chars)`,
    `- 💬 Comments: ${report.totalCommentChars.toLocaleString()} chars (excluded from ratio)`,
    '',
    '## By File',
    '',
    '| File | Human % | AI % | Human Chars | AI Chars | Comment Chars |',
    '|------|---------|------|-------------|----------|---------------|',
  ];

  for (const file of report.files) {
    const name = file.filePath.split(/[/\\]/).pop() ?? file.filePath;
    lines.push(
      `| ${name} | ${file.humanPercent}% | ${file.aiPercent}% | ${file.humanChars} | ${file.aiChars} | ${file.commentChars} |`
    );
  }

  return lines.join('\n');
}

/**
 * Returns the color associated with an authorship ratio for UI display.
 * Gradient from green (human) to red (AI).
 */
export function getAiRatioColor(aiPercent: number): string {
  if (aiPercent < 25) { return '#4caf50'; }   // green
  if (aiPercent < 50) { return '#ff9800'; }   // orange
  if (aiPercent < 75) { return '#f44336'; }   // red
  return '#9c27b0';                            // purple — heavily AI
}
